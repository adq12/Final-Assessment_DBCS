import java.io.*;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.rowset.JdbcRowSet;




public class Register extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String n=request.getParameter("Reg_No");
		String p=request.getParameter("Roll_No");
		String e=request.getParameter("Name");
		String c=request.getParameter("Father_Name");
		String a=request.getParameter("Mother_Name");
		String d=request.getParameter("Course");
		String g=request.getParameter("Semester");
		String h=request.getParameter("Year");
		
		
        //print on console
		    		System.out.println("Connected database successfully...");	
		    		
		
		
		try{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost/project","root","sweetheart2");
		PreparedStatement ps=con.prepareStatement("insert into registeruser values(?,?,?,?)");
		ps.setString(1,n);
		ps.setString(2,p);
		ps.setString(3,e);
		ps.setString(4,c);
		ps.setString(5,a);
		ps.setString(6,d);
		ps.setString(7,g);
		ps.setString(8,h);
		
		
		
		
		
		int i=ps.executeUpdate();
		if(i>0)
		out.print("You are successfully registered...");
		
			
		}catch (Exception e2) {System.out.println(e2);}
		
		out.close();
	}

}
